from flask import Flask, jsonify
import requests
from bs4 import BeautifulSoup
import time

app = Flask(__name__)

def get_free_proxies():
    url = "https://free-proxy-list.net/"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    proxies = []
    for row in soup.select("table tbody tr")[:20]:
        tds = row.find_all("td")
        ip = tds[0].text
        port = tds[1].text
        proxies.append(f"{ip}:{port}")
    return proxies

@app.route('/start')
def start_bot():
    video_urls = [
        "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        "https://www.youtube.com/watch?v=3JZ_D3ELwOQ",
        "https://www.youtube.com/watch?v=l482T0yNkeo",
    ]

    proxies = get_free_proxies()
    result = []

    for i, (video, proxy) in enumerate(zip(video_urls, proxies)):
        result.append(f"[{i+1}] Video: {video} | Proxy: {proxy}")
        time.sleep(1)  # Gerçek tarayıcı olmadığından sadece log simülasyonu

    return jsonify({
        "status": "Simülasyon tamamlandı",
        "log": result
    })

@app.route('/')
def home():
    return "Video Proxy Bot Çalışıyor. Başlatmak için /start"

if __name__ == '__main__':
    app.run()
